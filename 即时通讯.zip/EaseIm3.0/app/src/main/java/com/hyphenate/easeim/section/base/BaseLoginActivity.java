package com.hyphenate.easeim.section.base;

public abstract class BaseLoginActivity extends BaseInitActivity {

}
