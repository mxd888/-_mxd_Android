package com.hyphenate.easeim.section.message;

import com.hyphenate.chat.EMMessage;
import com.hyphenate.easeui.adapter.EaseBaseDelegateAdapter;

public class NewFriendsMsgAdapter extends EaseBaseDelegateAdapter<EMMessage> {

}
