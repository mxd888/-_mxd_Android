package com.hyphenate.easeim.section.group;

import android.text.TextUtils;

import com.hyphenate.chat.EMChatRoom;
import com.hyphenate.chat.EMClient;

public class ChatRoomHelper {

}

