package com.hyphenate.easeim.section.discover;

import android.os.Bundle;
import android.view.View;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.hyphenate.easeim.R;
import com.hyphenate.easeim.common.utils.ToastUtils;
import com.hyphenate.easeim.common.widget.ArrowItemView;
import com.hyphenate.easeim.section.base.BaseInitFragment;

public class DiscoverFragment extends BaseInitFragment implements View.OnClickListener{

    private ConstraintLayout clUserFriendShare;
    private ConstraintLayout clConversationMenuShi;
    private ArrowItemView itemConversationMenuScan;
    private ArrowItemView itemConversationMenuYao;
    private ArrowItemView itemConversationMenuKan;
    private ArrowItemView itemConversationMenuSou;

    @Override
    protected int getLayoutId() {
        return R.layout.demo_fragment_discover;
    }

    @Override
    protected void initView(Bundle savedInstanceState) {
        super.initView(savedInstanceState);
        clUserFriendShare = findViewById(R.id.cl_user_friend_share);
        clConversationMenuShi = findViewById(R.id.cl_conversation_menu_shi);
        itemConversationMenuScan = findViewById(R.id.item_conversation_menu_scan);
        itemConversationMenuYao = findViewById(R.id.item_conversation_menu_yao);
        itemConversationMenuKan = findViewById(R.id.item_conversation_menu_kan);
        itemConversationMenuSou = findViewById(R.id.item_conversation_menu_sou);
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cl_user_friend_share:
                ToastUtils.showSuccessToast("朋友圈---即将上线......");
                break;
            case R.id.cl_conversation_menu_shi:
                ToastUtils.showSuccessToast(null,"视频号---未来可期......",5);
                break;
            case R.id.item_conversation_menu_scan:
                ToastUtils.showToast("顶部导航里面有(*^▽^*)",5);
                break;
            case R.id.item_conversation_menu_yao:
                ToastUtils.showCenterToast(null,"摇一摇---火速开发中......",0,5);    // 即 默认样式
                break;
            case R.id.item_conversation_menu_kan:
                ToastUtils.showCenterToast(null,"看一看---即将发布......",1,5);    // 即 成功样式
                break;
            case R.id.item_conversation_menu_sou:
                ToastUtils.showCenterToast(null,"搜一搜---玩命开发中......",2,5);    // 即 失败样式
                break;

        }
    }

    @Override
    protected void initListener() {
        super.initListener();
        clUserFriendShare.setOnClickListener(this);
        clConversationMenuShi.setOnClickListener(this);
        itemConversationMenuScan.setOnClickListener(this);
        itemConversationMenuYao.setOnClickListener(this);
        itemConversationMenuKan.setOnClickListener(this);
        itemConversationMenuSou.setOnClickListener(this);
    }

    private void show(String show){

    }




}
