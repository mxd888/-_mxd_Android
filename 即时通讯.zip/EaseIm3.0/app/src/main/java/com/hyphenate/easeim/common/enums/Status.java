package com.hyphenate.easeim.common.enums;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
