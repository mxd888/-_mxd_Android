package com.hyphenate.easeim.common.utils;

import com.hyphenate.util.EMLog;

/**
 * log工具类
 */
public class DemoLog extends EMLog {

}
