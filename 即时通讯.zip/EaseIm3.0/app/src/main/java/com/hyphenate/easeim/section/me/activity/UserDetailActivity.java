package com.hyphenate.easeim.section.me.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import com.hyphenate.chat.EMClient;
import com.hyphenate.chat.EMPushConfigs;
import com.hyphenate.easeim.DemoApplication;
import com.hyphenate.easeim.DemoHelper;
import com.hyphenate.easeim.R;
import com.hyphenate.easeim.common.constant.DemoConstant;
import com.hyphenate.easeim.common.db.DemoDbHelper;
import com.hyphenate.easeim.common.db.dao.EmUserDao;
import com.hyphenate.easeim.common.livedatas.LiveDataBus;
import com.hyphenate.easeim.common.widget.ArrowItemView;
import com.hyphenate.easeim.section.base.BaseInitActivity;
import com.hyphenate.easeui.EaseIM;
import com.hyphenate.easeui.domain.EaseUser;
import com.hyphenate.easeui.provider.EaseUserProfileProvider;
import com.hyphenate.easeui.widget.EaseImageView;
import com.hyphenate.easeui.widget.EaseTitleBar;
import com.hyphenate.exceptions.HyphenateException;

public class UserDetailActivity extends BaseInitActivity {
    private EaseTitleBar titleBar;
    private EaseImageView itemUserAvatar;
    private ArrowItemView itemHxId;
    private ArrowItemView itemNickname;

    public static void actionStart(Context context) {
        Intent intent = new Intent(context, UserDetailActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.demo_activity_user_detail;
    }

    @Override
    protected void initView(Bundle savedInstanceState) {
        super.initView(savedInstanceState);
        titleBar = findViewById(R.id.title_bar);
        itemUserAvatar = findViewById(R.id.tv_title);
        itemHxId = findViewById(R.id.item_hx_id);
        itemNickname = findViewById(R.id.item_nickname);
    }

    @Override
    protected void initListener() {
        super.initListener();
        titleBar.setOnBackPressListener(new EaseTitleBar.OnBackPressListener() {
            @Override
            public void onBackPress(View view) {
                onBackPressed();
            }
        });
        itemNickname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OfflinePushNickActivity.actionStart(mContext);
            }
        });
        // 监听头像点击
        itemUserAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getNickname();
            }
        });
    }

    @Override
    protected void initData() {
        super.initData();
        itemHxId.getTvContent().setText(DemoHelper.getInstance().getCurrentUser());
        getNickname();
//        getUserAvatar();
        LiveDataBus.get().with(DemoConstant.REFRESH_NICKNAME, Boolean.class).observe(this, event -> {
            if(event == null) {
                return;
            }
            if(event) {
                getNickname();
            }
        });
    }

    // 获取用户昵称
    private void getNickname() {
        EMPushConfigs configs = null;
        try {
//            configs = EMClient.getInstance().pushManager().getPushConfigsFromServer();
//            String nickname = configs.getDisplayNickname();


            String nickname = EMClient.getInstance().getCurrentUser();


            // 获取所有好友哦
            //Map<String, EaseUser> list = DemoHelper.getInstance().getModel().getContactList();
            //Log.i("list-->",list.toString()+"--"+list.size());

            if(!TextUtils.isEmpty(nickname)) {
                itemNickname.getTvContent().setText(nickname);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // 获取用户头像
    // /{org_name}/{app_name}/users/{username}
    private void getUserAvatar() {
        EMPushConfigs configs = null;
        try {
            configs = EMClient.getInstance().pushManager().getPushConfigsFromServer();
            Log.i("用户信息-->",configs.toString());
            String nickname = configs.getDisplayNickname();
            if(!TextUtils.isEmpty(nickname)) {

//                itemNickname.getTvContent().setText(nickname);
//
//
                EaseIM.getInstance().setUserProvider(new EaseUserProfileProvider() {
                    @Override
                    public EaseUser getUser(String username) {
                        //根据username，从数据库中或者内存中取出之前保存的用户信息，如从数据库中取出的用户对象为DemoUserBean
//                        DemoUserBean bean = getUserFromDbOrMemery(username);

                        EaseUser user = new EaseUser(username);

                        //设置用户昵称
//                        user.setNickname(bean.getNickname());
//                        //设置头像地址
//                        user.setAvatar(bean.getAvatar());
                        //最后返回构建的EaseUser对象
                        return user;
                    }
                });


            }
        } catch (HyphenateException e) {
            e.printStackTrace();
        }
    }


    /**
     * EmUserDao
     * @return db
     */
    public EmUserDao getUserDao() {
        return DemoDbHelper.getInstance(DemoApplication.getInstance()).getUserDao();
    }
}
